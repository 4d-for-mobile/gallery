<p align="center"><img src="https://github.com/4d-for-ios/4d-for-ios-form-list-SimpleTable/blob/master/template.gif" alt="Simple Table" height="auto" width="300"></p>

## Simple Table

* **Type:** Table
* **Section:** available
* **Actions:** cell left swipe
* **Image required:** no

## How to integrate

* To use a list form template, the first thing you'll need to do is create a YourDatabase.4dbase/Resources/Mobile/form/list folder.
* Then drop the list form folder into it.
